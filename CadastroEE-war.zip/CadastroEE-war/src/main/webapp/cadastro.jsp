<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="br.com.cadastro.model.Produto" %>
<%
    Produto produto = (Produto) request.getAttribute("produto");
    boolean isUpdate = (produto != null);
%>
<!DOCTYPE html>
<html>
<head>
    <title><%= isUpdate ? "Alterar Produto" : "Novo Produto" %></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h1><%= isUpdate ? "Alterar Produto" : "Adicionar Novo Produto" %></h1>
    <form action="ServletProdutoFC?acao=<%= isUpdate ? "alterar" : "incluir" %>" method="post">
        <% if (isUpdate) { %>
            <input type="hidden" name="idProduto" value="<%= produto.getIdProduto() %>">
        <% } %>
        <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" id="nome" name="nome" class="form-control" value="<%= isUpdate ? produto.getNome() : "" %>" required>
        </div>
        <div class="mb-3">
            <label for="quantidade" class="form-label">Quantidade</label>
            <input type="number" id="quantidade" name="quantidade" class="form-control" value="<%= isUpdate ? produto.getQuantidade() : "" %>" required>
        </div>
        <div class="mb-3">
            <label for="preco" class="form-label">Preço de Venda</label>
            <input type="number" step="0.01" id="preco" name="preco" class="form-control" value="<%= isUpdate ? produto.getPreco() : "" %>" required>
        </div>
        <button type="submit" class="btn btn-success">Salvar</button>
        <a href="ServletProdutoFC?acao=listar" class="btn btn-secondary">Cancelar</a>
    </form>
</body>
</html>