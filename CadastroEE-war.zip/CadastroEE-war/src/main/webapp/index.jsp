<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="br.com.cadastro.model.Produto" %>
<%
    List<Produto> produtos = (List<Produto>) request.getAttribute("produtos");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Listagem de Produtos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h1 class="mb-4">Listagem de Produtos</h1>
    <a href="ServletProdutoFC?acao=formIncluir" class="btn btn-primary mb-3">Novo Produto</a>
    <table class="table table-striped">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Nome</th>
                <th>Quantidade</th>
                <th>Preço de Venda</th>
                <th>Opções</th>
            </tr>
        </thead>
        <tbody>
        <% if (produtos != null && !produtos.isEmpty()) {
            for (Produto p : produtos) { %>
                <tr>
                    <td><%= p.getIdProduto() %></td>
                    <td><%= p.getNome() %></td>
                    <td><%= p.getQuantidade() %></td>
                    <td>R$ <%= String.format("%.2f", p.getPreco()) %></td>
                    <td>
                        <a href="ServletProdutoFC?acao=formAlterar&idProduto=<%= p.getIdProduto() %>" class="btn btn-sm btn-primary">Alterar</a>
						<a href="ServletProdutoFC?acao=excluir&idProduto=<%= p.getIdProduto() %>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir?');">Excluir</a>
					</td>
                </tr>
        <%   }
        } else { %>
            <tr>
                <td colspan="5" class="text-center">Nenhum produto encontrado.</td>
            </tr>
        <% } %>
        </tbody>
    </table>
</body>
</html>