package br.com.cadastro.web;

import br.com.cadastro.model.Produto;
import br.com.cadastro.ejb.ProdutoFacadeLocal;

import jakarta.ejb.EJB;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "ServletProdutoFC", urlPatterns = {"/ServletProdutoFC"})
public class ServletProdutoFC extends HttpServlet {

    private static final long serialVersionUID = -8010490634600155483L;

    @EJB
    private ProdutoFacadeLocal facade;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String acao = request.getParameter("acao");
        String destino;

        if (acao == null) {
            acao = "listar";
        }

        switch (acao) {
            case "listar":
                request.setAttribute("produtos", facade.findAll());
                destino = "index.jsp";
                break;

            case "formIncluir":
                destino = "cadastro.jsp";
                break;

            case "formAlterar":
                String idParam = request.getParameter("idProduto");
                if (idParam != null && !idParam.isEmpty()) {
                    Long id = Long.parseLong(idParam);
                    Produto produtoExistente = facade.find(id);
                    request.setAttribute("produto", produtoExistente);
                    destino = "cadastro.jsp";
                } else {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Parâmetro 'idProduto' ausente ou inválido.");
                    return;
                }
                break;

            case "incluir":
                Produto novoProduto = new Produto();
                novoProduto.setNome(request.getParameter("nome"));
                novoProduto.setQuantidade(Integer.parseInt(request.getParameter("quantidade")));
                novoProduto.setPreco(Double.parseDouble(request.getParameter("preco")));
                facade.create(novoProduto);
                response.sendRedirect("ServletProdutoFC?acao=listar");
                return;

            case "alterar":
                String idAlterar = request.getParameter("idProduto");
                if (idAlterar != null && !idAlterar.isEmpty()) {
                    Long id = Long.parseLong(idAlterar);
                    Produto produtoAlterar = facade.find(id);
                    produtoAlterar.setNome(request.getParameter("nome"));
                    produtoAlterar.setQuantidade(Integer.parseInt(request.getParameter("quantidade")));
                    produtoAlterar.setPreco(Double.parseDouble(request.getParameter("preco")));
                    facade.edit(produtoAlterar);
                    response.sendRedirect("ServletProdutoFC?acao=listar");
                    return;
                } else {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Parâmetro 'idProduto' ausente ou inválido.");
                    return;
                }

            case "excluir":
                String idExcluir = request.getParameter("idProduto");
                if (idExcluir != null && !idExcluir.isEmpty()) {
                    Long id = Long.parseLong(idExcluir);
                    Produto produtoExcluir = facade.find(id);
                    if (produtoExcluir != null) {
                        facade.remove(produtoExcluir);
                    }
                    response.sendRedirect("ServletProdutoFC?acao=listar");
                    return;
                } else {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Parâmetro 'idProduto' ausente ou inválido.");
                    return;
                }

            default:
                destino = "index.jsp";
                break;
        }

        RequestDispatcher dispatcher = request.getRequestDispatcher(destino);
        dispatcher.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}