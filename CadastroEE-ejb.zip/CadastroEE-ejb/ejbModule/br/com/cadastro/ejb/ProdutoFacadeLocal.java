package br.com.cadastro.ejb;

import br.com.cadastro.model.Produto;
import java.util.List;
import jakarta.ejb.Local;

@Local
public interface ProdutoFacadeLocal {
    void create(Produto produto);
    void edit(Produto produto);
    void remove(Produto produto);
    Produto find(Object idProduto);
    List<Produto> findAll();
}